# Inference and Monitoring Architecture

```mermaid
flowchart TD
    A[data/new_messages.csv] --> B[Batch predict command]
    B --> C[Validate required text columns]
    C --> D[Shared preprocessing]
    D --> E[Load saved TF-IDF vectorizer]
    E --> F[Transform text]
    F --> G[Load selected trained model]
    G --> H[Predict Type 2, Type 3, Type 4]
    H --> I[Decode labels]
    H --> J[Calculate confidence when available]
    I --> K[Write predictions.csv]
    J --> K
    K --> L[Review prediction volumes, confidence, and future labelled errors]
    L --> M[Trigger retraining when performance or data drift requires it]
```
