# Training Pipeline Architecture

```mermaid
flowchart TD
    A[data/train.csv] --> B[Load CSV]
    B --> C[Validate text and Type 2/3/4 columns]
    C --> D[Handle missing text and remove missing labels]
    D --> E[Shared preprocessing]
    E --> F[Train/test split with random_state]
    F --> G[Fit TF-IDF vectorizer on train text]
    G --> H[Train Logistic Regression multi-output model]
    G --> I[Train Random Forest multi-output model]
    H --> J[Predict test labels]
    I --> J
    J --> K[Normal classification metrics per label]
    J --> L[Dependent hierarchical accuracy]
    K --> M[Select best model]
    L --> M
    M --> N[Save model.joblib]
    M --> O[Save vectorizer.joblib and label_encoders.joblib]
    M --> P[Save metrics, reports, predictions, error analysis]
```
