from sklearn.ensemble import RandomForestClassifier
from sklearn.multioutput import MultiOutputClassifier

from config import RANDOM_STATE
from models.base_model import BaseModel


class RandomForestModel(BaseModel):
    name = "random_forest"

    def __init__(self) -> None:
        base_estimator = RandomForestClassifier(
            n_estimators=300,
            class_weight="balanced_subsample",
            random_state=RANDOM_STATE,
            n_jobs=-1,
        )
        self.estimator = MultiOutputClassifier(base_estimator)

    def fit(self, X, y):
        self.estimator.fit(X, y)
        return self

    def predict(self, X):
        return self.estimator.predict(X)
