from sklearn.linear_model import LogisticRegression
from sklearn.multioutput import MultiOutputClassifier

from config import RANDOM_STATE
from models.base_model import BaseModel


class LogisticRegressionModel(BaseModel):
    name = "logistic_regression"

    def __init__(self) -> None:
        base_estimator = LogisticRegression(
            max_iter=1000,
            class_weight="balanced",
            random_state=RANDOM_STATE,
        )
        self.estimator = MultiOutputClassifier(base_estimator)

    def fit(self, X, y):
        self.estimator.fit(X, y)
        return self

    def predict(self, X):
        return self.estimator.predict(X)
