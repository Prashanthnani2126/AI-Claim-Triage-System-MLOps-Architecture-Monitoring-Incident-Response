from abc import ABC, abstractmethod


class BaseModel(ABC):
    name: str

    @abstractmethod
    def fit(self, X, y):
        pass

    @abstractmethod
    def predict(self, X):
        pass

    def predict_confidence(self, X):
        if not hasattr(self.estimator, "predict_proba"):
            return [None] * X.shape[0]

        probabilities = self.estimator.predict_proba(X)
        row_confidences = []
        for row_index in range(X.shape[0]):
            label_confidences = [float(level[row_index].max()) for level in probabilities]
            row_confidences.append(sum(label_confidences) / len(label_confidences))
        return row_confidences
