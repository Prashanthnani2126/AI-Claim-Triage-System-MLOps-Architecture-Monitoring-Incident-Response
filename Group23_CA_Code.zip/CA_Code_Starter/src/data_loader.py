from pathlib import Path

import pandas as pd

from config import LABEL_COLUMNS, TEXT_COLUMNS, TRAIN_DATA_PATH
from preprocessing import add_combined_text


def load_csv(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(f"Input file not found: {path}")
    return pd.read_csv(path, skipinitialspace=True)


def _normalise_columns(df: pd.DataFrame) -> pd.DataFrame:
    rename_map = {"y2": "Type 2", "y3": "Type 3", "y4": "Type 4"}
    return df.rename(columns=rename_map)


def validate_text_columns(df: pd.DataFrame) -> None:
    missing = [column for column in TEXT_COLUMNS if column not in df.columns]
    if missing:
        raise ValueError(
            "Missing required text column(s): "
            + ", ".join(missing)
            + ". Expected columns are: "
            + ", ".join(TEXT_COLUMNS)
        )


def validate_training_columns(df: pd.DataFrame) -> None:
    validate_text_columns(df)
    missing = [column for column in LABEL_COLUMNS if column not in df.columns]
    if missing:
        raise ValueError(
            "Missing required training label column(s): "
            + ", ".join(missing)
            + ". Training requires Type 2, Type 3 and Type 4."
        )


def load_training_data(path: Path = TRAIN_DATA_PATH) -> pd.DataFrame:
    df = _normalise_columns(load_csv(path))
    validate_training_columns(df)

    before = len(df)
    df = df.dropna(subset=LABEL_COLUMNS).copy()
    for column in LABEL_COLUMNS:
        df[column] = df[column].astype(str).str.strip()
    df = df[(df[LABEL_COLUMNS] != "").all(axis=1)].copy()
    dropped = before - len(df)
    if len(df) == 0:
        raise ValueError("No valid training rows remain after removing missing labels.")

    df = add_combined_text(df)
    empty_text_rows = df["text"].eq("").sum()
    if empty_text_rows == len(df):
        raise ValueError("All training rows have empty text after preprocessing.")
    df.attrs["dropped_missing_label_rows"] = dropped
    df.attrs["empty_text_rows"] = int(empty_text_rows)
    return df


def load_prediction_data(path: Path) -> pd.DataFrame:
    df = _normalise_columns(load_csv(path))
    validate_text_columns(df)
    df = add_combined_text(df)
    if df["text"].eq("").all():
        raise ValueError("All prediction rows have empty text after preprocessing.")
    return df
