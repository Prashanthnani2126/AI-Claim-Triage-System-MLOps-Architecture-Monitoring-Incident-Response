from sklearn.feature_extraction.text import TfidfVectorizer

from config import TFIDF_MAX_FEATURES


def build_vectorizer() -> TfidfVectorizer:
    return TfidfVectorizer(
        max_features=TFIDF_MAX_FEATURES,
        min_df=2,
        max_df=0.95,
        ngram_range=(1, 2),
    )
