import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def ensure_directories(*paths: Path) -> None:
    for path in paths:
        path.mkdir(parents=True, exist_ok=True)


def save_json(data: dict[str, Any], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as file:
        json.dump(data, file, indent=2)


def utc_timestamp() -> str:
    return datetime.now(timezone.utc).isoformat()
