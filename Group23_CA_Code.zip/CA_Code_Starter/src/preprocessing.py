import re

import pandas as pd

from config import TEXT_COLUMNS


def clean_text(value: object) -> str:
    if pd.isna(value):
        return ""
    text = str(value).lower()
    text = re.sub(r"xxxxx@xxxx\.com|\*{5}\([a-z]+\)", " ", text)
    text = re.sub(r"\b(re|fw|fwd|sv|wg|ynt)\s*:", " ", text)
    text = re.sub(r"[^0-9a-zA-Z]+", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def add_combined_text(df: pd.DataFrame) -> pd.DataFrame:
    prepared = df.copy()
    for column in TEXT_COLUMNS:
        prepared[column] = prepared[column].apply(clean_text)
    prepared["text"] = (
        prepared[TEXT_COLUMNS[0]].fillna("") + " " + prepared[TEXT_COLUMNS[1]].fillna("")
    ).str.strip()
    return prepared
