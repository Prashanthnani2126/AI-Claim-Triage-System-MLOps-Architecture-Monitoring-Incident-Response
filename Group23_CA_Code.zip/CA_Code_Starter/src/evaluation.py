import pandas as pd
from sklearn.metrics import accuracy_score, classification_report

from config import LABEL_COLUMNS


def hierarchical_row_score(true_row, pred_row) -> float:
    type2_correct = true_row[0] == pred_row[0]
    type3_correct = true_row[1] == pred_row[1]
    type4_correct = true_row[2] == pred_row[2]

    if not type2_correct:
        return 0.0
    if not type3_correct:
        return 1 / 3
    if not type4_correct:
        return 2 / 3
    return 1.0


def hierarchical_accuracy(y_true, y_pred) -> tuple[float, list[float]]:
    scores = [
        hierarchical_row_score(true_row, pred_row)
        for true_row, pred_row in zip(y_true, y_pred)
    ]
    return float(sum(scores) / len(scores)), scores


def evaluate_model(model_name: str, y_true, y_pred) -> tuple[dict, pd.DataFrame]:
    hierarchical, row_scores = hierarchical_accuracy(y_true, y_pred)
    metrics = {
        "model_name": model_name,
        "dependent_hierarchical_accuracy": hierarchical,
        "exact_match_accuracy": float((y_true == y_pred).all(axis=1).mean()),
        "row_count": int(len(y_true)),
        "label_metrics": {},
    }

    report_frames = []
    for label_index, label_name in enumerate(LABEL_COLUMNS):
        report = classification_report(
            y_true[:, label_index],
            y_pred[:, label_index],
            output_dict=True,
            zero_division=0,
        )
        metrics["label_metrics"][label_name] = {
            "accuracy": float(accuracy_score(y_true[:, label_index], y_pred[:, label_index])),
            "macro_avg": report.get("macro avg", {}),
            "weighted_avg": report.get("weighted avg", {}),
        }
        frame = pd.DataFrame(report).transpose().reset_index(names="class_label")
        frame.insert(0, "label_level", label_name)
        frame.insert(0, "model_name", model_name)
        report_frames.append(frame)

    metrics["hierarchical_row_scores"] = row_scores
    return metrics, pd.concat(report_frames, ignore_index=True)


def build_prediction_frame(source_df: pd.DataFrame, y_true, y_pred, confidences, model_name: str) -> pd.DataFrame:
    result = pd.DataFrame(
        {
            "row_id": source_df.index,
            "input_text": source_df["text"].values,
            "true_Type 2": y_true[:, 0],
            "true_Type 3": y_true[:, 1],
            "true_Type 4": y_true[:, 2],
            "predicted_Type 2": y_pred[:, 0],
            "predicted_Type 3": y_pred[:, 1],
            "predicted_Type 4": y_pred[:, 2],
            "confidence": confidences,
            "model_name": model_name,
        }
    )
    result["hierarchical_score"] = [
        hierarchical_row_score(true_row, pred_row)
        for true_row, pred_row in zip(y_true, y_pred)
    ]
    return result
