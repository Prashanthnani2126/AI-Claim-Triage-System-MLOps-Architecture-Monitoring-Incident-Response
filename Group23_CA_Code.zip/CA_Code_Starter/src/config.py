from pathlib import Path


RANDOM_STATE = 42

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data"
ARTIFACTS_DIR = PROJECT_ROOT / "artifacts"
OUTPUTS_DIR = PROJECT_ROOT / "outputs"

TRAIN_DATA_PATH = DATA_DIR / "train.csv"
DEFAULT_PREDICTION_INPUT = DATA_DIR / "new_messages.csv"

TEXT_COLUMNS = ["Ticket Summary", "Interaction content"]
LABEL_COLUMNS = ["Type 2", "Type 3", "Type 4"]
ID_CANDIDATES = ["message_id", "row_id", "Ticket id", "Interaction id"]

MODEL_PATH = ARTIFACTS_DIR / "model.joblib"
VECTORIZER_PATH = ARTIFACTS_DIR / "vectorizer.joblib"
LABEL_ENCODERS_PATH = ARTIFACTS_DIR / "label_encoders.joblib"
METADATA_PATH = ARTIFACTS_DIR / "metadata.json"

METRICS_PATH = OUTPUTS_DIR / "metrics.json"
CLASSIFICATION_REPORT_PATH = OUTPUTS_DIR / "classification_report.csv"
TRAINING_PREDICTIONS_PATH = OUTPUTS_DIR / "predictions.csv"
ERROR_ANALYSIS_PATH = OUTPUTS_DIR / "error_analysis.csv"

TFIDF_MAX_FEATURES = 5000
TEST_SIZE = 0.2
