import argparse
import sys
from pathlib import Path

import joblib
import pandas as pd

sys.path.append(str(Path(__file__).resolve().parent))

from config import (  # noqa: E402
    ID_CANDIDATES,
    LABEL_COLUMNS,
    LABEL_ENCODERS_PATH,
    MODEL_PATH,
    VECTORIZER_PATH,
)
from data_loader import load_prediction_data  # noqa: E402
from utils import utc_timestamp  # noqa: E402


def decode_predictions(encoded_predictions, encoders):
    decoded = {}
    for index, column in enumerate(LABEL_COLUMNS):
        decoded[column] = encoders[column].inverse_transform(
            encoded_predictions[:, index].astype(int)
        )
    return decoded


def choose_id_column(df: pd.DataFrame) -> str | None:
    for column in ID_CANDIDATES:
        if column in df.columns:
            return column
    return None


def main() -> None:
    parser = argparse.ArgumentParser(description="Run batch message classification.")
    parser.add_argument("--input", required=True, help="Path to input CSV.")
    parser.add_argument("--output", required=True, help="Path to output predictions CSV.")
    args = parser.parse_args()

    model = joblib.load(MODEL_PATH)
    vectorizer = joblib.load(VECTORIZER_PATH)
    encoders = joblib.load(LABEL_ENCODERS_PATH)

    input_path = Path(args.input)
    output_path = Path(args.output)
    df = load_prediction_data(input_path)
    X = vectorizer.transform(df["text"])

    encoded_predictions = model.predict(X)
    decoded = decode_predictions(encoded_predictions, encoders)
    confidences = model.predict_confidence(X)
    timestamp = utc_timestamp()
    id_column = choose_id_column(df)

    output = pd.DataFrame()
    output["row_id"] = df[id_column].values if id_column else df.index
    output["input_text"] = df["text"].values
    output["predicted Type 2"] = decoded["Type 2"]
    output["predicted Type 3"] = decoded["Type 3"]
    output["predicted Type 4"] = decoded["Type 4"]
    output["confidence"] = confidences
    output["model_name"] = model.name
    output["prediction_timestamp"] = timestamp

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output.to_csv(output_path, index=False)
    print(f"Saved predictions to {output_path}")


if __name__ == "__main__":
    main()
