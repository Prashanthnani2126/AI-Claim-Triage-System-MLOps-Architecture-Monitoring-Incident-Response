import sys
from pathlib import Path

import joblib
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

sys.path.append(str(Path(__file__).resolve().parent))

from config import (  # noqa: E402
    ARTIFACTS_DIR,
    CLASSIFICATION_REPORT_PATH,
    ERROR_ANALYSIS_PATH,
    LABEL_COLUMNS,
    LABEL_ENCODERS_PATH,
    METADATA_PATH,
    METRICS_PATH,
    MODEL_PATH,
    OUTPUTS_DIR,
    RANDOM_STATE,
    TEST_SIZE,
    TRAINING_PREDICTIONS_PATH,
    VECTORIZER_PATH,
)
from data_loader import load_training_data  # noqa: E402
from evaluation import build_prediction_frame, evaluate_model  # noqa: E402
from features import build_vectorizer  # noqa: E402
from models import LogisticRegressionModel, RandomForestModel  # noqa: E402
from utils import ensure_directories, save_json, utc_timestamp  # noqa: E402


def encode_labels(df: pd.DataFrame):
    encoders = {}
    encoded_columns = []
    for column in LABEL_COLUMNS:
        encoder = LabelEncoder()
        encoded_columns.append(encoder.fit_transform(df[column]))
        encoders[column] = encoder
    return pd.DataFrame(dict(zip(LABEL_COLUMNS, encoded_columns)), index=df.index), encoders


def decode_labels(encoded_values, encoders: dict[str, LabelEncoder]):
    decoded = encoded_values.astype(object).copy()
    for index, column in enumerate(LABEL_COLUMNS):
        decoded[:, index] = encoders[column].inverse_transform(encoded_values[:, index].astype(int))
    return decoded.astype(str)


def main() -> None:
    ensure_directories(ARTIFACTS_DIR, OUTPUTS_DIR)
    df = load_training_data()
    y_encoded, encoders = encode_labels(df)

    stratify = df["Type 2"] if df["Type 2"].value_counts().min() >= 2 else None
    train_df, test_df, y_train, y_test = train_test_split(
        df,
        y_encoded,
        test_size=TEST_SIZE,
        random_state=RANDOM_STATE,
        stratify=stratify,
    )

    vectorizer = build_vectorizer()
    X_train = vectorizer.fit_transform(train_df["text"])
    X_test = vectorizer.transform(test_df["text"])
    y_train_array = y_train.to_numpy()
    y_test_array = y_test.to_numpy()
    y_test_decoded = decode_labels(y_test_array, encoders)

    models = [LogisticRegressionModel(), RandomForestModel()]
    all_metrics = {}
    report_frames = []
    best_model = None
    best_predictions = None
    best_confidences = None
    best_score = -1.0

    for model in models:
        model.fit(X_train, y_train_array)
        predictions = model.predict(X_test)
        predictions_decoded = decode_labels(predictions, encoders)
        confidences = model.predict_confidence(X_test)

        metrics, report = evaluate_model(model.name, y_test_decoded, predictions_decoded)
        all_metrics[model.name] = metrics
        report_frames.append(report)

        score = metrics["dependent_hierarchical_accuracy"]
        if score > best_score:
            best_score = score
            best_model = model
            best_predictions = predictions_decoded
            best_confidences = confidences

    if best_model is None:
        raise RuntimeError("No model was trained successfully.")

    best_prediction_frame = build_prediction_frame(
        test_df,
        y_test_decoded,
        best_predictions,
        best_confidences,
        best_model.name,
    )
    error_analysis = best_prediction_frame[best_prediction_frame["hierarchical_score"] < 1.0]

    joblib.dump(best_model, MODEL_PATH)
    joblib.dump(vectorizer, VECTORIZER_PATH)
    joblib.dump(encoders, LABEL_ENCODERS_PATH)

    metadata = {
        "trained_at": utc_timestamp(),
        "random_state": RANDOM_STATE,
        "best_model": best_model.name,
        "label_columns": LABEL_COLUMNS,
        "text_columns": ["Ticket Summary", "Interaction content"],
        "training_rows": int(len(train_df)),
        "test_rows": int(len(test_df)),
        "dropped_missing_label_rows": int(df.attrs.get("dropped_missing_label_rows", 0)),
        "empty_text_rows": int(df.attrs.get("empty_text_rows", 0)),
    }
    save_json(metadata, METADATA_PATH)

    metrics_output = {
        "best_model": best_model.name,
        "best_dependent_hierarchical_accuracy": best_score,
        "models": all_metrics,
    }
    save_json(metrics_output, METRICS_PATH)
    pd.concat(report_frames, ignore_index=True).to_csv(CLASSIFICATION_REPORT_PATH, index=False)
    best_prediction_frame.to_csv(TRAINING_PREDICTIONS_PATH, index=False)
    error_analysis.to_csv(ERROR_ANALYSIS_PATH, index=False)

    print(f"Best model: {best_model.name}")
    print(f"Dependent hierarchical accuracy: {best_score:.4f}")
    print(f"Saved model to {MODEL_PATH}")
    print(f"Saved metrics to {METRICS_PATH}")


if __name__ == "__main__":
    main()
